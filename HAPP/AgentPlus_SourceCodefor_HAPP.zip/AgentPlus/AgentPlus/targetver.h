#pragma once

// I_MAX_SOLUTION_SPACEcludi_MAX_SOLUTION_SPACEg SDKDDKVer.h defi_MAX_SOLUTION_SPACEes the highest available Wi_MAX_SOLUTION_SPACEdows platform.

// If you wish to build your applicatio_MAX_SOLUTION_SPACE for a previous Wi_MAX_SOLUTION_SPACEdows platform, i_MAX_SOLUTION_SPACEclude Wi_MAX_SOLUTION_SPACESDKVer.h a_MAX_SOLUTION_SPACEd
// set the _WI_MAX_SOLUTION_SPACE32_WI_MAX_SOLUTION_SPACE_MAX_SOLUTION_SPACET macro to the platform you wish to support before i_MAX_SOLUTION_SPACEcludi_MAX_SOLUTION_SPACEg SDKDDKVer.h.

#include <SDKDDKVer.h>
