#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <omp.h>
#include <algorithm>
#include <time.h>
#include "AgentPlus.h"
#include "CSVParser.h"

#define _MAX_NUMBER_OF_PASSENGERS 100
#define _MAX_NUMBER_OF_STATES 1000

using namespace std;

FILE* g_pFileDebugLog = NULL;

FILE* g_pFileOutputLog = NULL;

FILE* g_pFileAgentPathLog = NULL;

int g_passenger_capacity[_MAX_NUMBER_OF_PASSENGERS] = { 1 };
int g_number_of_passengers = 0;
int g_node_passenger_id[_MAX_NUMBER_OF_NODES] = { -1 };
int g_node_passenger_pickup_flag[_MAX_NUMBER_OF_NODES] = { 0 };

int g_passenger_origin_node[_MAX_NUMBER_OF_PASSENGERS];  // traveling passengers
int g_passenger_destination_node[_MAX_NUMBER_OF_PASSENGERS];

int g_passenger_departure_time_beginning[_MAX_NUMBER_OF_PASSENGERS];
int g_passenger_departure_time_ending[_MAX_NUMBER_OF_PASSENGERS];
int g_passenger_arrival_time_beginning[_MAX_NUMBER_OF_PASSENGERS];
int g_passenger_arrival_time_ending[_MAX_NUMBER_OF_PASSENGERS];
int g_passenger_transfer_cutoff_time[_MAX_NUMBER_OF_PASSENGERS];

int g_vehicle_origin_node[_MAX_NUMBER_OF_VEHICLES];  // for vehcile routings
int g_vehicle_destination_node[_MAX_NUMBER_OF_VEHICLES];
int g_vehicle_departure_time_beginning[_MAX_NUMBER_OF_VEHICLES] = { 0 };
int g_vehicle_departure_time_ending[_MAX_NUMBER_OF_VEHICLES];
int g_vehicle_arrival_time_beginning[_MAX_NUMBER_OF_VEHICLES] = { 120 };
int g_vehicle_arrival_time_ending[_MAX_NUMBER_OF_VEHICLES];
int g_vehicle_capacity[_MAX_NUMBER_OF_VEHICLES] = { 1 };

int g_vehicle_serving_passenger_matrix[_MAX_NUMBER_OF_VEHICLES][_MAX_NUMBER_OF_PASSENGERS] = { 0 };
int g_vehicle_path_number_of_nodes[_MAX_NUMBER_OF_VEHICLES] = { 0 };
float g_vehicle_path_cost[_MAX_NUMBER_OF_VEHICLES] = { 0 };  // for vehcile routings

float g_VOIVTT_per_hour[_MAX_NUMBER_OF_VEHICLES];
float g_VOWT_per_hour[_MAX_NUMBER_OF_VEHICLES];

std::map<int, int> g_internal_link_no_map;
std::map<int, int> g_external_link_id_map;
int g_link_from_node_id[_MAX_NUMBER_OF_LINKS];
int g_link_to_node_id[_MAX_NUMBER_OF_LINKS];
int g_link_service_code[_MAX_NUMBER_OF_LINKS] = { 0 };
int g_link_service_pax_code[_MAX_NUMBER_OF_LINKS] = { 0 }; // equals to passenger id
int g_link_from_state_code[_MAX_NUMBER_OF_LINKS] = { -1 };
int g_link_to_state_code[_MAX_NUMBER_OF_LINKS] = { -1 };
int g_link_free_flow_travel_time[_MAX_NUMBER_OF_LINKS];
float g_link_free_flow_travel_time_float_value[_MAX_NUMBER_OF_LINKS];

float g_arc_travel_time[_MAX_NUMBER_OF_LINKS][_MAX_NUMBER_OF_TIME_INTERVALS] = { 0 };

std::map<int, int> g_internal_node_no_map;
std::map<int, int> g_external_node_id_map;
int g_node_passenger_flag[_MAX_NUMBER_OF_NODES] = { -1 };
int g_node_vehicle_flag[_MAX_NUMBER_OF_NODES] = { -1 };
int g_node_starting_time[_MAX_NUMBER_OF_NODES] = { 0 };
int g_node_ending_time[_MAX_NUMBER_OF_NODES] = { 99999 };
int g_node_cutoff_time[_MAX_NUMBER_OF_NODES] = { 99999 };
int g_node_location_code[_MAX_NUMBER_OF_NODES] = { -1 };

int g_outbound_node_size[_MAX_NUMBER_OF_NODES] = { 0 };
int g_inbound_node_size[_MAX_NUMBER_OF_NODES];
int g_maximum_number_name_of_nodes = 0;

//configuration
int g_shortest_path_debugging_flag = 1;
int g_number_of_threads = 4;

class CVR_Service_State  //class for vehicle scheduling service states
{
public:
	int sequence_no;
	int passenger_service_state[_MAX_NUMBER_OF_PASSENGERS]; // code is 0, 1, 2, ..., 8, 9
	int m_passenger_occupancy;  // to do
	int m_boundary_state_flag;

	CVR_Service_State()
	{
		m_boundary_state_flag = 1;  // true
		m_passenger_occupancy = 0;

		for (int p = 0; p < _MAX_NUMBER_OF_PASSENGERS; p++)
		{
			passenger_service_state[p] = 0;
		}
	}

	bool IsBoundaryState()
	{
		if (m_boundary_state_flag == 1)
			return true;
		else
			return false;
	}

	std::string generate_string_key()
	{
		std::string string_key;

		for (int p = 1; p <= g_number_of_passengers; p++)  // scan all passengers
		{
			stringstream s;

			s << "_";

			if (passenger_service_state[p] >= 0)
			{
				s << passenger_service_state[p];
			}
			else // -1
			{
				s << " ";
			}

			string converted(s.str());

			string_key += converted;

		}
		return string_key;  //e.g. _ _ _ or _1_2_3 or or _1*_2*_3* or _1_2_3*
	}
};

std::map<std::string, int> g_service_state_map;  // hash table for mapping unique string key to the numerical state index s

int g_find_service_state_index(std::string string_key)
{
	if (g_service_state_map.find(string_key) != g_service_state_map.end())
	{
		return g_service_state_map[string_key];
	}
	else
	{
		return -1;  // not found
	}
}

std::vector<CVR_Service_State> g_VRStateServiceVector;

int g_add_service_states(int w_state_index, int link_no, int vehilce_no, int from_state_code, int to_state_code) // return the find index
{
	CVR_Service_State element = g_VRStateServiceVector[w_state_index];

	if (from_state_code >= 0) //if the node is not a transportation node
	{
		CVR_Service_State new_element;

		int pax_capacity_demand = 0;

		for (int p = 1; p <= g_number_of_passengers; p++)  // copy vector states //173 link has pax code
		{
			new_element.passenger_service_state[p] = element.passenger_service_state[p];

			if (element.passenger_service_state[p] == 1)
				pax_capacity_demand += g_passenger_capacity[p];
		}

		if (g_link_service_pax_code[link_no] >= 1) // if the link has pax code
		{
			int passenger_id = g_link_service_pax_code[link_no];

			if (element.passenger_service_state[passenger_id] == from_state_code)
			{
				if ((g_link_service_code[link_no] == 2) || (g_link_service_code[link_no] == 4)) //drop-off or push
				{
					new_element.passenger_service_state[passenger_id] = to_state_code;
					new_element.m_passenger_occupancy = pax_capacity_demand - g_passenger_capacity[passenger_id];
				}
				else //pick-up or pull
				{
					int total_pax_occupancy = pax_capacity_demand + g_passenger_capacity[passenger_id];

					if (total_pax_occupancy <= g_vehicle_capacity[vehilce_no]) //to check the vehicle capacity
					{
						new_element.passenger_service_state[passenger_id] = to_state_code;
						new_element.m_passenger_occupancy = total_pax_occupancy;
					}
				}
			}
		}
		else // to be added 
		{
			return w_state_index;
		}

		std::string string_key = new_element.generate_string_key();
		int state_index = g_find_service_state_index(string_key);  // find if the newly generated state node has been defined already

		// to do: check if the state is good enough
		if (state_index == -1)  // no
		{
			// add new state
			state_index = g_VRStateServiceVector.size();
			g_VRStateServiceVector.push_back(new_element);
			g_service_state_map[string_key] = state_index;
		}  //otherwise, do nothing}

		return state_index;
	}
}

float**** la_state_node_label_cost = NULL;
int**** la_state_node_predecessor = NULL;
int**** la_state_time_predecessor = NULL;
int**** la_state_service_predecessor = NULL;
int**** la_state_vehicle_predecessor = NULL;

int g_number_of_nodes = 0;
int g_number_of_physical_nodes = 0;
int g_number_of_links = 0;
int g_number_of_time_intervals = 100;
int g_number_of_vehicles = 0;

//parallel computing 
float**** lp_state_node_label_cost = NULL;
int**** lp_state_node_predecessor = NULL;
int**** lp_state_time_predecessor = NULL;
int**** lp_state_carrying_predecessor = NULL;

float*** g_v_arc_cost = NULL;
float*** g_v_vertex_waiting_cost = NULL;

//void g_allocate_memory_DP()
//{
//	int number_of_states = 100;
//	int number_of_nodes = g_number_of_nodes + 1;
//	int number_of_links = g_number_of_links + 1;
//	int number_of_time_intervals = g_number_of_time_intervals + 1;
//	int number_of_vehicles = g_number_of_vehicles + 1;
//
//	g_v_arc_cost = Allocate3DDynamicArray<float>(number_of_vehicles, number_of_links, number_of_time_intervals);
//	g_v_vertex_waiting_cost = Allocate3DDynamicArray<float>(number_of_vehicles, number_of_nodes, number_of_time_intervals);
//
//	lp_state_node_label_cost = Allocate4DDynamicArray<float>(number_of_vehicles, number_of_nodes, number_of_time_intervals, number_of_states);
//	lp_state_node_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_nodes, number_of_time_intervals, number_of_states);
//	lp_state_time_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_nodes, number_of_time_intervals, number_of_states);
//	lp_state_carrying_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_nodes, number_of_time_intervals, number_of_states);
//
//	la_state_node_label_cost = Allocate4DDynamicArray<float>(number_of_vehicles, number_of_time_intervals, number_of_states, number_of_nodes);
//	la_state_node_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_time_intervals, number_of_states, number_of_nodes);
//	la_state_time_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_time_intervals, number_of_states, number_of_nodes);
//	la_state_service_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_time_intervals, number_of_states, number_of_nodes);
//	la_state_vehicle_predecessor = Allocate4DDynamicArray<int>(number_of_vehicles, number_of_time_intervals, number_of_states, number_of_nodes);
//}

//void g_free_memory_DP() //no need to free memory
//{
//	int number_of_states = 100;
//	int number_of_nodes = g_number_of_nodes + 1;
//	int number_of_links = g_number_of_links + 1;
//	int number_of_time_intervals = g_number_of_time_intervals + 1;
//	int number_of_vehicles = g_number_of_vehicles + 1;
//
//	Deallocate4DDynamicArray<float>(lp_state_node_label_cost, number_of_vehicles, number_of_nodes, number_of_time_intervals);
//	Deallocate4DDynamicArray<int>(lp_state_node_predecessor, number_of_vehicles, number_of_nodes, number_of_time_intervals);
//	Deallocate4DDynamicArray<int>(lp_state_time_predecessor, number_of_vehicles, number_of_nodes, number_of_time_intervals);
//	Deallocate4DDynamicArray<int>(lp_state_carrying_predecessor, number_of_vehicles, number_of_nodes, number_of_time_intervals);
//
//	Deallocate4DDynamicArray<float>(la_state_node_label_cost, number_of_vehicles, number_of_time_intervals, number_of_states);
//	Deallocate4DDynamicArray<int>(la_state_node_predecessor, number_of_vehicles, number_of_time_intervals, number_of_states);
//	Deallocate4DDynamicArray<int>(la_state_time_predecessor, number_of_vehicles, number_of_time_intervals, number_of_states);
//	Deallocate4DDynamicArray<int>(la_state_service_predecessor, number_of_vehicles, number_of_time_intervals, number_of_states);
//	Deallocate4DDynamicArray<int>(la_state_vehicle_predecessor, number_of_vehicles, number_of_time_intervals, number_of_states);
//}

float g_integrated_assignment_routing_dynamic_programming()
{
	// step 1: Initialization for all nodes

	for (int v = 0; v <= g_number_of_vehicles; v++) //Initialization for all nodes
	{
		for (int t = 0; t < g_number_of_time_intervals; t++)
		{
			for (int s = 0; s < _MAX_NUMBER_OF_STATES; s++)
			{
				for (int i = 0; i <= g_number_of_nodes; i++) //Initialization for all nodes
				{
					la_state_node_label_cost[v][t][s][i] = _MAX_LABEL_COST;
					la_state_node_predecessor[v][t][s][i] = -1;  // pointer to previous NODE INDEX from the current label at current node and time
					la_state_time_predecessor[v][t][s][i] = -1;  // pointer to previous TIME INDEX from the current label at current node and time
					la_state_service_predecessor[v][t][s][i] = -1;
					la_state_vehicle_predecessor[v][t][s][i] = -1;
				}
			}
		}
	}

	//step 2: Initialization for origin node at the preferred departure time, at departure time
	int s0 = 0;  // start from empty
	int origin_node = g_vehicle_origin_node[1]; //vehicle depot
	int departure_time_beginning = g_vehicle_departure_time_beginning[1];

	la_state_node_label_cost[1][departure_time_beginning][s0][origin_node] = 0;

	for (int v = 1; v <= g_number_of_vehicles; v++) // 1st loop for vehicle
	{
		int arrival_time_ending = g_vehicle_arrival_time_ending[v];
		departure_time_beginning = g_vehicle_departure_time_beginning[v];
		int vehicle_capacity = g_vehicle_capacity[v];

		for (int t = departure_time_beginning; t <= arrival_time_ending; t++)  //2nd loop: time
		{
			if (t % 100 == 0)
			{
				cout << " vehicle " << v << " is scanning time " << t << "..." << endl;
			}

			for (int link = 0; link < g_number_of_links; link++)  // 3d loop for each link (i,j)
			{
				int from_node = g_link_from_node_id[link];  //i
				int to_node = g_link_to_node_id[link];  // j

				int from_state_code = g_link_from_state_code[link];
				int to_state_code = g_link_to_state_code[link];

				for (int s1 = 0; s1 < g_VRStateServiceVector.size(); s1++)  // 3rd loop, service state
				{
					if (g_VRStateServiceVector[s1].m_passenger_occupancy > vehicle_capacity) // skip all states exceeding vehicle capacity
						continue;

					int travel_time = g_link_free_flow_travel_time[link];

					if (la_state_node_label_cost[v][t][s1][from_node] < _MAX_LABEL_COST - 1)  // for feasible time-space point only
					{
						int s2 = g_add_service_states(s1, link, v, from_state_code, to_state_code); // s2 == -1 continue

						if (g_VRStateServiceVector[s2].m_passenger_occupancy > vehicle_capacity)
							continue;

						// part 1: link based update
						int new_to_node_arrival_time = min(t + travel_time, g_number_of_time_intervals - 1);

						if (g_node_passenger_id[to_node] >= 1 && g_node_starting_time[to_node] >= 0 && g_node_ending_time[to_node] >= 0)
							// passegner activity node: origin or destination //g_node_passenger_id equals to 
						{
							if (new_to_node_arrival_time < g_node_starting_time[to_node]
								|| new_to_node_arrival_time > g_node_ending_time[to_node])
							{
								// skip scanning when the destination nodes arrival time is out of time window
								continue;
							}
						}

						// if (g_shortest_path_debugging_flag)
						// fprintf(g_pFileDebugLog, "SP: checking from node %d, to node %d at time %d, FFTT = %d\n",
						// from_node, to_node, new_to_node_arrival_time,  g_link_free_flow_travel_time[link_no]);
						float temporary_label_cost = la_state_node_label_cost[v][t][s1][from_node] + g_v_arc_cost[v][link][t];

						if (temporary_label_cost < la_state_node_label_cost[v][new_to_node_arrival_time][s2][to_node]) // we only compare cost at the downstream node ToID at the new arrival time t
						{
							//if (g_shortest_path_debugging_flag)
							//{
							//	fprintf(g_pFileDebugLog, "DP: updating node: %d from time %d to time %d, current cost: %.2f, from cost %.2f ->%.2f\n",
							//		to_node, t, new_to_node_arrival_time,
							//		lp_state_node_label_cost[p][from_node][t][w2],
							//		lp_state_node_label_cost[p][to_node][new_to_node_arrival_time][w2], temporary_label_cost);
							//}

							// update cost label and node/time predecessor

							la_state_node_label_cost[v][new_to_node_arrival_time][s2][to_node] = temporary_label_cost;
							la_state_node_predecessor[v][new_to_node_arrival_time][s2][to_node] = from_node;  // pointer to previous NODE INDEX from the current label at current node and time
							la_state_time_predecessor[v][new_to_node_arrival_time][s2][to_node] = t;  // pointer to previous TIME INDEX from the current label at current node and time
							la_state_service_predecessor[v][new_to_node_arrival_time][s2][to_node] = s1;
							la_state_vehicle_predecessor[v][new_to_node_arrival_time][s2][to_node] = v;
						}
						// part 2: same node based update for waiting arcs

						if (s2 == s1) // for the same state
						{
							new_to_node_arrival_time = min(t + 1, g_number_of_time_intervals - 1);

							//					if (g_shortest_path_debugging_flag)
							//						fprintf(g_pFileDebugLog, "SP: checking from node %d, to node %d at time %d, FFTT = %d\n",
							//					from_node, to_node, new_to_node_arrival_time,  g_link_free_flow_travel_time[link_no]);
							temporary_label_cost = la_state_node_label_cost[v][t][s1][from_node] + g_v_vertex_waiting_cost[v][from_node][t];

							if (temporary_label_cost < la_state_node_label_cost[v][new_to_node_arrival_time][s1][from_node]) // we only compare cost at the downstream node ToID at the new arrival time t
							{
								// update cost label and node/time predecessor

								la_state_node_label_cost[v][new_to_node_arrival_time][s1][from_node] = temporary_label_cost;
								la_state_node_predecessor[v][new_to_node_arrival_time][s1][from_node] = from_node;  // pointer to previous NODE INDEX from the current label at current node and time
								la_state_time_predecessor[v][new_to_node_arrival_time][s1][from_node] = t;  // pointer to previous TIME INDEX from the current label at current node and time
								la_state_service_predecessor[v][new_to_node_arrival_time][s1][from_node] = s1;
								la_state_vehicle_predecessor[v][new_to_node_arrival_time][s1][from_node] = v;
							}
						}
					}  // feasible vertex label cost
				}  // for all links
			} // for all states
		} // for all time t

		  // RACE relay section from v to v+1

		if (v < g_number_of_vehicles)
		{
			for (int s = 0; s < g_VRStateServiceVector.size(); s++)  //  service state
			{
				// boundary states only
				if (g_VRStateServiceVector[s].IsBoundaryState() == true)
				{ // relay the state-dependent label cost from vehicle v to vehicle v+1
				  // from time T to 0 // from destination node of v to origin node of v+1

					std::string str = g_VRStateServiceVector[s].generate_string_key();

					int t1 = g_vehicle_arrival_time_ending[v];
					int t2 = g_vehicle_departure_time_beginning[v + 1];
					int node1 = g_vehicle_destination_node[v];
					int node2 = g_vehicle_origin_node[v + 1];

					if (la_state_node_label_cost[v][t1][s][node1] < _MAX_LABEL_COST)
					{
						fprintf(g_pFileDebugLog, "vehicle %d: relaying state no. %d:(%d) %s, with label cost %f\n",
							v,
							s,
							g_VRStateServiceVector[s].m_passenger_occupancy,
							str.c_str(),
							la_state_node_label_cost[v][t1][s][node1]);

						la_state_node_label_cost[v + 1][t2][s][node2] = la_state_node_label_cost[v][t1][s][node1];
						la_state_node_predecessor[v + 1][t2][s][node2] = la_state_node_predecessor[v][t1][s][node1];
						la_state_time_predecessor[v + 1][t2][s][node2] = la_state_time_predecessor[v][t1][s][node1];
						la_state_service_predecessor[v + 1][t2][s][node2] = la_state_service_predecessor[v][t1][s][node1];
						la_state_vehicle_predecessor[v + 1][t2][s][node2] = v;
					}
				}
			}
		}
	}  // for different vehicles

	double total_cost = _MAX_LABEL_COST;

	int reversed_path_vehicle_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int reversed_path_time_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int reversed_path_state_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int reversed_path_node_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	float reversed_path_cost_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];

	int last_s = 1;  // 1 for all serviced state node
	int last_v = g_number_of_vehicles; //g_number_of_physical_vehicles;
	int destination_node = g_vehicle_destination_node[last_v];
	int arrival_time = g_vehicle_arrival_time_ending[last_v];
	total_cost = la_state_node_label_cost[last_v][arrival_time][last_s][destination_node];

	// step 2: backtrack to the origin (based on node and time predecessors)
	int	node_size = 0;
	reversed_path_node_sequence[node_size] = destination_node;//record the first node backward, destination node
	reversed_path_time_sequence[node_size] = arrival_time;
	reversed_path_state_sequence[node_size] = last_s;
	reversed_path_vehicle_sequence[node_size] = last_v;
	reversed_path_cost_sequence[node_size] = la_state_node_label_cost[last_v][arrival_time][last_s][destination_node];

	node_size++;

	int pred_node = la_state_node_predecessor[last_v][arrival_time][last_s][destination_node];
	int pred_time = la_state_time_predecessor[last_v][arrival_time][last_s][destination_node];
	int pred_state = la_state_service_predecessor[last_v][arrival_time][last_s][destination_node];
	int pred_vehicle = la_state_vehicle_predecessor[last_v][arrival_time][last_s][destination_node];

	while (pred_node != -1 && node_size < _MAX_NUMBER_OF_TIME_INTERVALS) // scan backward in the predessor array of the shortest path calculation results
	{
		reversed_path_node_sequence[node_size] = pred_node;
		reversed_path_time_sequence[node_size] = pred_time;
		reversed_path_state_sequence[node_size] = pred_state;
		reversed_path_vehicle_sequence[node_size] = pred_vehicle;
		reversed_path_cost_sequence[node_size] = la_state_node_label_cost[pred_vehicle][pred_time][pred_state][pred_node];

		node_size++;

		//record current values of node and time predecessors, and update PredNode and PredTime

		int pred_node_record = pred_node;
		int pred_time_record = pred_time;
		int pred_state_record = pred_state;
		int pred_vehicle_record = pred_vehicle;

		pred_node = la_state_node_predecessor[pred_vehicle_record][pred_time_record][pred_state_record][pred_node_record];
		pred_time = la_state_time_predecessor[pred_vehicle_record][pred_time_record][pred_state_record][pred_node_record];
		pred_state = la_state_service_predecessor[pred_vehicle_record][pred_time_record][pred_state_record][pred_node_record];
		pred_vehicle = la_state_vehicle_predecessor[pred_vehicle_record][pred_time_record][pred_state_record][pred_node_record];
	}

	//reverse the node sequence 
	int l_path_vehicle_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int l_path_time_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int l_path_state_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	int l_path_node_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];
	float l_path_cost_sequence[_MAX_NUMBER_OF_STEP_INTERVALS];

	double prev_cost = -1;

	for (int n = 0; n < node_size; n++)
	{
		l_path_node_sequence[n] = reversed_path_node_sequence[node_size - n - 1];
		l_path_time_sequence[n] = reversed_path_time_sequence[node_size - n - 1];
		l_path_state_sequence[n] = reversed_path_state_sequence[node_size - n - 1];
		l_path_vehicle_sequence[n] = reversed_path_vehicle_sequence[node_size - n - 1];
		l_path_cost_sequence[n] = reversed_path_cost_sequence[node_size - n - 1];

		std::string str = g_VRStateServiceVector[l_path_state_sequence[n]].generate_string_key();

		float cost = l_path_cost_sequence[n];

		if (fabs(cost - prev_cost) > 0.0001)
		{
			fprintf(g_pFileDebugLog, "\index %d, Vehicle %d, time = %d, node = %d, state = %s, cost = %f\n",
				n,
				l_path_vehicle_sequence[n],
				l_path_time_sequence[n],
				g_external_node_id_map[l_path_node_sequence[n]],
				str.c_str(),
				cost);
		}

		prev_cost = cost;
	}

	return total_cost;
}

void g_ReadConfiguration()
{
	CCSVParser parser;
	if (parser.OpenCSVFile("input_configuration.csv", true))
	{

		while (parser.ReadRecord())  // if this line contains [] mark, then we will also read field headers.
		{
			string name;

			int node_type;
			int node_id;

			int number_of_threads = 1;

			parser.GetValueByFieldName("shortest_path_debugging_details", g_shortest_path_debugging_flag);
			parser.GetValueByFieldName("max_number_of_threads_to_be_used", number_of_threads);

			if (number_of_threads <= 0)
				number_of_threads = 1;

			if (number_of_threads > omp_get_max_threads())
				number_of_threads = omp_get_max_threads();
			int a = omp_get_max_threads();
			g_number_of_threads = number_of_threads;

			break;  // only the first line
		}
		parser.CloseCSVFile();
	}
}

void g_ReadInputData()
{
	// initialization
	for (int i = 0; i < _MAX_NUMBER_OF_NODES; i++)
	{
		g_outbound_node_size[i] = 0;
		g_inbound_node_size[i] = 0;
	}

	// step 1: read node file 
	g_number_of_nodes = 0; // initialize  the counter to 0

	CCSVParser parser;
	if (parser.OpenCSVFile("input_node.csv", true))
	{
		std::map<int, int> node_id_map;

		while (parser.ReadRecord())  // if this line contains [] mark, then we will also read field headers.
		{	
			int node_no;
			int p_flag;
			int v_flag;
			int time_window_begin;
			int time_window_end;
			int cut_off_time;
			int location_code;

			if (parser.GetValueByFieldName("NodeNo", node_no) == false)
				continue;

			if (node_no <= 0 || g_number_of_nodes >= _MAX_NUMBER_OF_NODES)
			{
				cout << "node_no " << node_no << " is out of range" << endl;
				g_ProgramStop();
			}

			g_internal_node_no_map[node_no] = g_number_of_nodes;
			g_external_node_id_map[g_number_of_nodes] = node_no;

			parser.GetValueByFieldName("Pflag", p_flag);
			g_node_passenger_flag[g_number_of_nodes] = p_flag;

			parser.GetValueByFieldName("Vflag", v_flag);
			g_node_vehicle_flag[g_number_of_nodes] = v_flag;

			parser.GetValueByFieldName("TimeWindowBegin", time_window_begin);
			g_node_starting_time[g_number_of_nodes] = time_window_begin;

			parser.GetValueByFieldName("TimeWindowEnd", time_window_end);
			g_node_ending_time[g_number_of_nodes] = time_window_end;

			parser.GetValueByFieldName("CutOffTime", cut_off_time);
			g_node_cutoff_time[g_number_of_nodes] = cut_off_time;

			parser.GetValueByFieldName("LocationCode", location_code);
			g_node_location_code[g_number_of_nodes] = location_code;

			g_number_of_nodes++;

			if (g_number_of_nodes % 1000 == 0)
				cout << "reading " << g_number_of_nodes << " physical nodes.. " << endl;
		}

		cout << "number of physical nodes = " << g_number_of_nodes << endl;

		g_number_of_physical_nodes = g_number_of_nodes;

		fprintf(g_pFileOutputLog, "number of physical nodes =,%d\n", g_number_of_nodes);
		parser.CloseCSVFile();
	}

	// step 2: read link file 
	g_number_of_links = 0; // initialize  the counter to 0

	if (parser.OpenCSVFile("input_link.csv", true))
	{
		while (parser.ReadRecord())  // if this line contains [] mark, then we will also read field headers.
		{
			int link_no;
			int from_node_no;
			int to_node_no;
			int link_service_code;
			int link_service_pax_code;
			int from_state_code;
			int to_state_code;

			if (parser.GetValueByFieldName("LinkNo", link_no) == false)
				continue;

			g_internal_link_no_map[link_no] = g_number_of_links;
			g_external_link_id_map[g_number_of_links] = link_no;

			parser.GetValueByFieldName("FromNodeNo", from_node_no);
			parser.GetValueByFieldName("ToNodeNo", to_node_no);

			int directional_from_node_id = g_internal_node_no_map[from_node_no];
			int directional_to_node_id = g_internal_node_no_map[to_node_no];

			if (from_node_no <= 0)
			{
				cout << "from_node_no " << from_node_no << " is out of range" << endl;
				g_ProgramStop();
			}

			if (to_node_no <= 0)
			{
				cout << "to_node_no " << to_node_no << " is out of range" << endl;
				g_ProgramStop();
			}

			g_link_from_node_id[g_number_of_links] = directional_from_node_id;
			g_link_to_node_id[g_number_of_links] = directional_to_node_id;

			parser.GetValueByFieldName("LinkServiceCode", link_service_code);
			g_link_service_code[g_number_of_links] = link_service_code;

			parser.GetValueByFieldName("LinkServicePaxCode", link_service_pax_code);
			g_link_service_pax_code[g_number_of_links] = link_service_pax_code;

			parser.GetValueByFieldName("FromStateCode", from_state_code);
			g_link_service_pax_code[g_number_of_links] = from_state_code;

			parser.GetValueByFieldName("ToStateCode", to_state_code);
			g_link_service_pax_code[g_number_of_links] = to_state_code;

			float link_length = 1;
			float speed = 1;
			float travel_time = 1.0;

			parser.GetValueByFieldName("length", link_length);
			parser.GetValueByFieldName("speed_limit", speed);
			if (speed >= 70)
				speed = 70;

			if (speed <= 25)
				speed = 25;

			travel_time = max(1, link_length * 60 / max(1, speed));

			if (travel_time > 1000)
			{
				cout << "travel time of link " << from_node_no << " -> " << to_node_no << " > 1000";
				g_ProgramStop();
			}

			g_link_free_flow_travel_time[g_number_of_links] = max(1, travel_time + 0.5);   // at least 1 min, round to nearest integers

			// increase the link counter by 1
			g_number_of_links++;

			if (g_number_of_links % 1000 == 0)
				cout << "reading " << g_number_of_links << "physical links.. " << endl;
		}

		cout << "number of physical links = " << g_number_of_links << endl;

		fprintf(g_pFileOutputLog, "number of physical links =,%d\n", g_number_of_links);

		parser.CloseCSVFile();
	}

	int temp_passenger_id = -1;

	for (int n = 0; n < g_number_of_nodes; n++) //add passenger info according to node info
	{
		if (g_node_passenger_flag[n] > 0) 
		{
			g_node_passenger_id[n] = g_node_passenger_flag[n];
			
			if (temp_passenger_id < g_node_passenger_flag[n]) // a new passenger can be added
			{
				if (g_node_location_code[n] == 0) //origin node of current passenger
				{
					g_node_passenger_pickup_flag[n] = 1;
					g_passenger_origin_node[g_number_of_passengers + 1] = n; // internal node_no
					g_passenger_departure_time_beginning[g_number_of_passengers + 1] = g_node_starting_time[n];
					g_passenger_departure_time_ending[g_number_of_passengers + 1] = g_node_ending_time[n];
				}
				else if (g_node_location_code[n] == 9) // dest node of current passenger
				{
					g_passenger_destination_node[g_number_of_passengers + 1] = n; // internal node_no
					g_passenger_arrival_time_beginning[g_number_of_passengers + 1] = g_node_starting_time[n];
					g_passenger_arrival_time_ending[g_number_of_passengers + 1] = g_node_ending_time[n];
				}
				else if (g_node_location_code[n] == 2) // transfer node of current passenger
				{
					g_passenger_transfer_cutoff_time[g_number_of_passengers + 1] = g_node_cutoff_time[n];
				}

				temp_passenger_id = g_node_passenger_flag[n];
				g_number_of_passengers++;
			}
		}
	}

	int temp_vehilce_id = -1;

	for (int n = 0; n < g_number_of_nodes; n++) //add vehilce info according to node info
	{
		if (g_node_vehicle_flag[n] > 0)
		{
			if (temp_vehilce_id < g_node_vehicle_flag[n]) // a new vehicle can be added
			{
				if (g_node_location_code[n] == 0) //origin node of current vehicle
				{
					g_vehicle_origin_node[g_number_of_vehicles + 1] = n;
					g_vehicle_departure_time_beginning[g_number_of_vehicles + 1] = g_node_starting_time[n];
					g_vehicle_departure_time_ending[g_number_of_vehicles + 1] = g_node_ending_time[n];
				}
				else if (g_node_location_code[n] == 9) // dest node of current vehicle
				{
					g_vehicle_destination_node[g_number_of_vehicles + 1] = n;
					g_vehicle_arrival_time_beginning[g_number_of_vehicles + 1] = g_node_starting_time[n];
					g_vehicle_arrival_time_ending[g_number_of_vehicles + 1] = g_node_ending_time[n];
				}

				temp_vehilce_id = g_node_vehicle_flag[n];
				g_number_of_vehicles++;
			}
		}
	}

	cout << "number of passengers= " << g_number_of_passengers << endl;
	fprintf(g_pFileOutputLog, "number of passengers=, %d\n", g_number_of_passengers);

	cout << "number of vehicles = " << g_number_of_vehicles << endl;
	fprintf(g_pFileOutputLog, "number of vehicles =,%d\n", g_number_of_vehicles);
}

void g_ProgramStop()
{
	cout << "Program stops. Press any key to terminate. Thanks!" << endl;
	getchar();
	exit(0);
}

void g_FulfillArcTravelAndNodeWaitingCost(float VOIVTT_per_hour)
{
	for (int v = 1; v <= g_number_of_vehicles; v++)
	{
		// setup arc travelling cost
		for (int link = 0; link < g_number_of_links; link++)
		{
			for (int t = 0; t < g_number_of_time_intervals; t++)
			{
				g_v_arc_cost[v][link][t] = g_arc_travel_time[link][t] / 60.0 * VOIVTT_per_hour;  // 60 min per hour
				if (g_arc_travel_time[link][t] > 0)
				{
					int q = 0;
				}
			}
		}

		// setup waiting cost
		for (int node = 0; node <= g_number_of_nodes; node++)
		{
			for (int t = 0; t <= g_number_of_time_intervals; t++)
			{
				g_v_vertex_waiting_cost[v][node][t] = 0;
			}
		}
	}
}

bool g_Optimization_Integrated_Assignment_Routing_Method_Vehicle_Routing_Problem() // need to re-check
{
	fprintf(g_pFileOutputLog, "\n");

	cout << "Preparation......" << endl;
	int VOIVTT_per_hour = 50;
	g_FulfillArcTravelAndNodeWaitingCost(VOIVTT_per_hour);//convert link travel time to arc travelling cost, and set all node waiting cost to be 0

	//step 0: initialization 
	fprintf(g_pFileDebugLog, "step 0: initialization \n");

	if (_MAX_NUMBER_OF_LINKS < g_number_of_links)
	{
		cout << "Number of links = " << g_number_of_links << ", which is greater then the max threshold of " << _MAX_NUMBER_OF_LINKS;
		g_ProgramStop();
	}

	for (int link = 0; link < g_number_of_links; link++)
	{
		for (int t = 0; t < g_number_of_time_intervals; t++)
		{
			g_arc_travel_time[link][t] = g_link_free_flow_travel_time[link];  //transportation cost
		}
	}

	// setup waiting cost
	for (int node = 0; node <= g_number_of_nodes; node++)
	{
		for (int t = 0; t <= g_number_of_time_intervals; t++)
		{
			for (int v = 1; v <= g_number_of_vehicles; v++)//note that the scheduling sequence does not matter  here
			{
				g_v_vertex_waiting_cost[v][node][t] = 1;
				//g_vertex_visit_count_for_lower_bound[v][node][t] = 0;
			}
		}
	}

	for (int v = 1; v <= g_number_of_vehicles; v++)
		for (int p = 1; p <= g_number_of_passengers; p++)
		{
			g_vehicle_serving_passenger_matrix[v][p] = 0;
		}

	//step 2: shortest path for vehicle
	for (int v = 1; v <= g_number_of_vehicles; v++)//note that the scheduling sequence does not matter  here  // include both physical and virtual vehicles
	{
		// set arc cost, to_node_cost and waiting_cost for vehicles

		for (int link = 0; link < g_number_of_links; link++)
		{
			for (int t = 0; t < g_number_of_time_intervals; t++)
			{
				g_v_arc_cost[v][link][t] = g_arc_travel_time[link][t] / 60.0 * g_VOIVTT_per_hour[v];  // 60 min pur hour
			}
		}

		// setup waiting cost
		for (int node = 0; node <= g_number_of_nodes; node++)
		{
			for (int t = 0; t <= g_number_of_time_intervals; t++)
			{
				g_v_vertex_waiting_cost[v][node][t] = 1 / 60.0* g_VOWT_per_hour[v];
			}
		}
		// special case: no waiting cost at vehicle returning depot

		for (int t = 0; t <= g_number_of_time_intervals; t++)
		{
			int vehicle_destination_node = g_vehicle_destination_node[v];
			g_v_vertex_waiting_cost[v][vehicle_destination_node][t] = 0;
		}
	}

	//fprintf(g_pFileDebugLog, "\n");
	float path_cost_by_vehicle_v = g_integrated_assignment_routing_dynamic_programming();

	//back trace
	//cout << "Running Time:" << g_GetAppRunningTime() << endl;

	return true;
}

int main(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	g_pFileDebugLog = fopen("Debug.txt", "w");

	if (g_pFileDebugLog == NULL)
	{
		cout << "File Debug.txt cannot be opened." << endl;
		g_ProgramStop();
	}

	g_pFileOutputLog = fopen("output_solution.csv", "w");

	if (g_pFileOutputLog == NULL)
	{
		cout << "File output_solution.csv cannot be opened." << endl;
		g_ProgramStop();
	}

	g_pFileAgentPathLog = fopen("agent_path.csv", "w");

	if (g_pFileAgentPathLog == NULL)
	{
		cout << "File agent_path.csv cannot be opened." << endl;
		g_ProgramStop();
	}

	fprintf(g_pFileAgentPathLog, "iteration_no,agent_id,agent_type,virtual_vehicle,path_node_sequence,path_time_sequence,path_state_sequence,\n"); // header

	g_ReadConfiguration();
	g_ReadInputData();

	fprintf(g_pFileOutputLog, "number of time intervals =,%d\n", g_number_of_time_intervals);

	cout << "number of time intervals =" << g_number_of_time_intervals << endl;

	// define timestamps
	clock_t start_t, end_t, total_t;
	int i;

	start_t = clock();

	g_Optimization_Integrated_Assignment_Routing_Method_Vehicle_Routing_Problem();

	end_t = clock();

	total_t = (end_t - start_t);

	cout << "CPU Running Time = " << total_t << " milliseconds" << endl;

	fprintf(g_pFileDebugLog, "CPU Running Time = %ld milliseconds\n", total_t);
	fprintf(g_pFileOutputLog, "CPU Running Time =,%ld, milliseconds\n", total_t);

	fclose(g_pFileOutputLog);
	fclose(g_pFileDebugLog);
	fclose(g_pFileAgentPathLog);

	cout << "End of Optimization " << endl;

	cout << "free memory.." << endl;

	cout << "done." << endl;

	return nRetCode;
}